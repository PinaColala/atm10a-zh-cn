package me.fengming.vaultpatcher_asm.loader.fabric;

import com.chocohead.mm.api.ClassTinkerers;
import me.fengming.vaultpatcher_asm.VaultPatcher;
import me.fengming.vaultpatcher_asm.config.VaultPatcherConfig;
import me.fengming.vaultpatcher_asm.core.patch.ClassPatcher;
import me.fengming.vaultpatcher_asm.core.transformers.VPClassTransformer;
import me.fengming.vaultpatcher_asm.core.transformers.VPMinecraftTransformer;
import me.fengming.vaultpatcher_asm.core.utils.Platform;
import me.fengming.vaultpatcher_asm.core.utils.Utils;
import me.fengming.vaultpatcher_asm.loader.LoaderBootstrap;
import me.fengming.vaultpatcher_asm.loader.LoaderBootstrapContext;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Field;
import java.nio.file.Path;

public class EarlyRiser implements Runnable {
    @Override
    public void run() {
        VaultPatcher.debugInfo("Loading VPEarlyRiser");

        final FabricLoader loader = FabricLoader.getInstance();
        LoaderBootstrap.bootstrap(new LoaderBootstrapContext() {
            @Override
            public String loaderName() {
                return "Fabric";
            }

            @Override
            public Platform platform() {
                return Platform.Fabric;
            }

            @Override
            public Path gameDir() {
                return loader.getGameDir();
            }

            @Override
            public boolean isClient() {
                return loader.getEnvironmentType() == EnvType.CLIENT;
            }

            @Override
            public String resolveMinecraftVersion() {
                return getMinecraftVersion();
            }
        });

        // do patches
        if (VaultPatcherConfig.isEnableClassPatch()) {
            ClassPatcher.getPatches().forEach((k, v) -> ClassTinkerers.addReplacement(k, n -> Utils.deepCopyClass(n, v)));
        }

        Utils.translationInfoMap.forEach((k, v) -> ClassTinkerers.addTransformation(k, new VPClassTransformer(v)));

        if (!Utils.dynTranslationInfos.isEmpty()) addMinecraftClasses();

        VaultPatcher.debugInfo("ER DONE!");
    }

    private static void addMinecraftClasses() {
        ClassTinkerers.addTransformation("net.minecraft.class_327", new VPMinecraftTransformer());
        ClassTinkerers.addTransformation("net.minecraft.class_2585", new VPMinecraftTransformer());
        ClassTinkerers.addTransformation("net.minecraft.class_5348", new VPMinecraftTransformer());
        ClassTinkerers.addTransformation("net.minecraft.class_8828$class_2585", new VPMinecraftTransformer());
        ClassTinkerers.addTransformation("net.minecraft.client.gui.Font", new VPMinecraftTransformer());
        ClassTinkerers.addTransformation("net.minecraft.network.chat.contents.PlainTextContents$LiteralContents", new VPMinecraftTransformer());
        ClassTinkerers.addTransformation("net.minecraft.network.chat.FormattedText", new VPMinecraftTransformer());
    }


    private static String getMinecraftVersion() {
        try {
            // Fabric
            return getNormalizedGameVersion(Class.forName("net.fabricmc.loader.impl.FabricLoaderImpl"));
        } catch (Exception ignored) {}
        try {
            // Quilt
            return getNormalizedGameVersion(Class.forName("org.quiltmc.loader.impl.QuiltLoaderImpl"));
        } catch (Exception ignored) {}
        return null;
    }

    private static String getNormalizedGameVersion(Class<?> clazz) throws Exception {
        Field field = clazz.getDeclaredField("INSTANCE");
        field.setAccessible(true);
        Object instance = field.get(null);
        Object gameProvider = instance.getClass().getDeclaredMethod("getGameProvider").invoke(instance);
        return (String) gameProvider.getClass().getDeclaredMethod("getNormalizedGameVersion").invoke(gameProvider);
    }
}
