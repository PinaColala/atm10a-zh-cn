package me.fengming.vaultpatcher_asm;

import me.fengming.vaultpatcher_asm.config.VaultPatcherConfig;
import me.fengming.vaultpatcher_asm.config.VaultPatcherModule;
import me.fengming.vaultpatcher_asm.core.cache.Caches;
import me.fengming.vaultpatcher_asm.core.misc.ILogger;
import me.fengming.vaultpatcher_asm.core.patch.ClassPatcher;
import me.fengming.vaultpatcher_asm.core.utils.I18n;
import me.fengming.vaultpatcher_asm.core.utils.Platform;
import me.fengming.vaultpatcher_asm.core.utils.Utils;
import me.fengming.vaultpatcher_asm.plugin.VaultPatcherPlugin;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarFile;

public class VaultPatcher {
    public static ILogger LOGGER = new ILogger();

    public static List<VaultPatcherPlugin> plugins = new ArrayList<>();
    public static Path mcPath = null;
    public static String mcVersion = null;
    public static Platform platform = Platform.UNDEFINED;
    public static boolean isClient = false;

    public static void init(Path mcPath, String mcVersion) {
        VaultPatcher.mcPath = mcPath;
        VaultPatcher.mcVersion = mcVersion;

        Path pluginsPath = Utils.getVpPath().resolve("plugins");
        if (Files.notExists(pluginsPath)) {
            try {
                Files.createDirectories(pluginsPath);
            } catch (IOException e) {
                throw new RuntimeException("Failed creating plugin directory: ", e);
            }
        }

        // Load Plugins
        File[] plugins = pluginsPath.toFile().listFiles(f -> f.getName().endsWith(".jar"));
        if (plugins != null) {
            for (File file : plugins) {
                try (JarFile jarFile = new JarFile(file)) {
                    String entryPoint = jarFile.getManifest().getMainAttributes().getValue("VaultPatcherPlugin");
                    if (entryPoint == null)
                        throw new RuntimeException("Failed loading plugin " + file.getName() + ": Couldn't find the entry point");

                    ClassLoader parentClassLoader = VaultPatcher.class.getClassLoader();
                    URLClassLoader classLoader = new URLClassLoader(new URL[]{file.toURI().toURL()}, parentClassLoader);
                    VaultPatcherPlugin plugin = classLoader.loadClass(entryPoint).asSubclass(VaultPatcherPlugin.class).newInstance();

                    VaultPatcher.plugins.add(plugin);
                } catch (Exception e) {
                    throw new RuntimeException("Failed loading plugin: " + file, e);
                }
            }
        }

        _init(mcPath);
    }

    private static void _init(Path mcPath) {
        plugins.forEach(e -> e.start(mcPath));

        try {
            plugins.forEach(e -> e.onLoadConfig(VaultPatcherPlugin.Phase.BEFORE));
            VaultPatcherConfig.readConfig(mcPath.resolve("config").resolve("vaultpatcher_asm"));
            Utils.debug = VaultPatcherConfig.getDebugMode();
            VaultPatcher.debugInfo("Loading Configs!");
            plugins.forEach(e -> e.onLoadConfig(VaultPatcherPlugin.Phase.AFTER));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config: ", e);
        }

        VaultPatcher.debugInfo("Loading I18n!");
        I18n.load(mcPath);

        try {
            VaultPatcher.debugInfo("Loading Patches!");
            plugins.forEach(e -> e.onLoadPatches(VaultPatcherPlugin.Phase.BEFORE));
            ClassPatcher.init(Utils.getVpPath().resolve("patch"));
            plugins.forEach(e -> e.onLoadPatches(VaultPatcherPlugin.Phase.AFTER));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load patch: ", e);
        }

        try {
            VaultPatcher.debugInfo("Loading Caches!");
            plugins.forEach(e -> e.onLoadCaches(VaultPatcherPlugin.Phase.BEFORE));
            Caches.init(Utils.getVpPath().resolve("cache"));
            plugins.forEach(e -> e.onLoadCaches(VaultPatcherPlugin.Phase.AFTER));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load cache: ", e);
        }

        try {
            VaultPatcher.debugInfo("Loading Modules!");
            Path p = Utils.getVpPath().resolve("modules");
            if (Files.notExists(p)) {
                Files.createDirectories(p);
            }
            if (VaultPatcherConfig.isLoadAllModules()) {
                try (DirectoryStream<Path> stream = Files.newDirectoryStream(p, "*.json")) {
                    for (Path jsonFile : stream) {
                        VaultPatcherModule vpp = new VaultPatcherModule(jsonFile.getFileName().toString());
                        plugins.forEach(e -> e.onLoadModule(vpp, VaultPatcherPlugin.Phase.BEFORE));
                        vpp.read();
                        plugins.forEach(e -> e.onLoadModule(vpp, VaultPatcherPlugin.Phase.AFTER));
                    }
                }

            } else {
                List<String> mods = VaultPatcherConfig.getMods();
                for (String mod : mods) {
                    VaultPatcherModule vpp = new VaultPatcherModule(mod + ".json");
                    plugins.forEach(e -> e.onLoadModule(vpp, VaultPatcherPlugin.Phase.BEFORE));
                    vpp.read();
                    plugins.forEach(e -> e.onLoadModule(vpp, VaultPatcherPlugin.Phase.AFTER));
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load modules: ", e);
        }


        // optimization
        Utils.needStacktrace = Utils.dynTranslationInfos.stream().anyMatch(e -> !e.getTargetClassInfo().getDynamicName().isEmpty());

        plugins.forEach(VaultPatcherPlugin::end);
    }

    public static void debugInfo(String s) {
        if (Utils.debug.isEnable()) VaultPatcher.LOGGER.info(s);
    }

    public static void debugInfo(String s, Object... args) {
        if (Utils.debug.isEnable()) VaultPatcher.LOGGER.info(s, args);
    }
}
